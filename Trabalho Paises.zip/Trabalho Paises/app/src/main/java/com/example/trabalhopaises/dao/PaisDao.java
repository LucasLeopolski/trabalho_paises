package com.example.trabalhopaises.dao;

public class PaisDao {
}
