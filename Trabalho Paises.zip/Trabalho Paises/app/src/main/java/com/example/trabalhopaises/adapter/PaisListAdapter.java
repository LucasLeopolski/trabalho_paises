package com.example.trabalhopaises.adapter;

import androidx.appcompat.app.AppCompatActivity;

public class PaisListAdapter extends AppCompatActivity {
}
