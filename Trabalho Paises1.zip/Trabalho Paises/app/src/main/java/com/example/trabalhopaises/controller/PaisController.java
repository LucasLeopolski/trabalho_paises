package com.example.trabalhopaises.controller;

public class PaisController {
}
