package com.example.trabalhopaises.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.RecyclerView;

import com.example.trabalhopaises.R;
import com.example.trabalhopaises.model.Pais;

import java.util.ArrayList;

public class PaisListAdapter extends RecyclerView.Adapter<PaisListAdapter.ViewHolder> {

    private ArrayList<Pais> listaPaises;

    private LayoutInflater inflater;

    public PaisListAdapter(Context context, ArrayList<Pais> listaPaises) {
        this.inflater = LayoutInflater.from(context);
        this.listaPaises = listaPaises;
    }
    @NonNull
    @Override
    public RecyclerView.ViewHolder onCreteViewHolder(ViewGroup parent, int viewType) {
        LayoutInflater inflater = LayoutInflater.from(parent.getContext());
        View view = inflater.inflate(R.layout.item_list_pais, parent, false);
        return new ViewHolder(view);
    }
    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position){
        Pais pais = listaPaises.get(position);

        holder.tvCodigo.setText(String.valueOf(pais.getCodigo()));
        holder.tvDescricao.setText(pais.getDescricao());
    }

    @Override
    public int getItemCount() {
        return this.listaPaises.size();
    }

    @Override
    public class ViewHolder extends  RecyclerView.ViewHolder {
        public TextView tvCodigo, tvDescricao;

        public ViewHolder(@NonNull View itemView){
            super(itemView);
            this.tvCodigo = itemView.findViewById(R.id.tvCodigo);
            this.tvDescricao = itemView.findViewById(R.id.tvDescricao);
        }
    }


}
