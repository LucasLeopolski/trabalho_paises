package com.example.trabalhopaises.retrofit;

public class RetrofitcConfig {
}
